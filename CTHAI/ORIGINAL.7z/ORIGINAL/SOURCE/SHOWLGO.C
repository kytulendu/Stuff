#include <stdlib.h>
#include <stdio.h>
#include <mem.h>
#include <dos.h>

#define set_writecolor(x) outport(0x03c4,0x0100*x+0x0002)
#define set_readplane(x) outport(0x03ce,0x0100*x+0x0004)

void Show_KMITT_logo(int x,int y,char *path)
{
	FILE *lgo;
	int plan,i;
	unsigned char *ll;
	unsigned char far *scr;

	if((ll = malloc(32))==NULL) return;
	x=x/8;
	lgo=fopen(path,"rb");
	if(lgo!=NULL){
		for(plan=0;plan<2;plan++)
		{
			switch(plan){
				case 0 : set_writecolor(7); break;
				case 1 : set_writecolor(8); break;
			}
			for(i=0;i<256;i++)
			{
				scr=MK_FP(0xA000,(i+y)*80+x);
				fread(ll,1,32,lgo);
				_fmemcpy(scr,ll,32);
			}
		}
		fclose(lgo);
	}
	free(ll);
}