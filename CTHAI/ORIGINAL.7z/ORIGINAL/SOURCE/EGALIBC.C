#include "egalib.h"

void _Line(int,int,int,int,int);
void ScanLine(int,int,int,int);

#define _iswap(a,b) \
{                             \
	int i;                    \
	i = *a;                   \
	*a = *b;                  \
	*b = i;                   \
}

void Line(int x1,int y1,int x2,int y2,int col)
{
	if(x1>x2) _iswap(&x1,&x2);
	if(y1>y2) _iswap(&y1,&y2);
	if(y1==y2)
		ScanLine(x1,x2,y1,col);
	else _Line(x1,y1,x2,y2,col);
}

void Solid_Box(int x1,int y1,int x2,int y2,int col)
{
	int i;
	if(x1>x2) _iswap(&x1,&x2);
	if(y1>y2) _iswap(&y1,&y2);
	for(i=y1;i<=y2;i++)
	{
		ScanLine(x1,x2,i,col);
	}
}