#include <egalib.h>
#include <thaivga.h>

main()
{
    int i,j,hi;
    char st[]="apichart apichart apichart apichart ��ԪҵԠ����ԭ �ѡ�ح��ҿ�Ҡ����駡�����";
    static font fn[256],ifn[256];

	Set_Mode(VM_GRAPHIC);

	if(Load_TFont(fn,"..\\font\\normal.fon")) exit(1);
	if(Load_TFont(ifn,"..\\font\\italic.fon"))  exit(1);

    for(j=0; j<16; j++){
	hi = Thai_Hight();
	Solid_Box(0,0,639,479,0);
	for(i=0; i<16; i++)
	    Solid_Box(0,i*hi,Thai_Width(st),i*hi+hi,i);

	Set_TColor(j);

	Set_TFont(fn);
	for(i=0;i<8;i++){
	    Out_ThaiV(i,i*20,st);
	}

	Set_TFont(ifn);
	for(i=8;i<16;i++){
		Out_ThaiV(0,i*20,st);
	}

	getch();
	}
	Set_Mode(VM_TEXT);
    return 0;
}

