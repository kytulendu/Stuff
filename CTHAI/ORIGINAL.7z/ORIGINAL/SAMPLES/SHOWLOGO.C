#include <egalib.h>
#include <showlgo.h>
#include <keyboard.h>

main()
{
	Set_Mode(VM_GRAPHIC);

	Show_KMITT_logo(100,100,"..\\font\\kmitt.lgo");

	Get_KB();
	Set_Mode(VM_TEXT);
	return 0;
}
