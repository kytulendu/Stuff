void edit_title()
{
	char title[80],filename[80];
	int old_tcol=Get_TColor(),old_edbk=Get_EditBKColor();

	g_title(title);
	g_filename(filename);
	Solid_Box(150,170,490,270,LIGHTGRAY);
	Rectangle(150,170,490,270,LIGHTBLUE);
	Set_EditBKColor(15);
	Set_TColor(0);
	Out_ThaiV(160,180,"Title");
	Out_ThaiV(160,220,"Filename");
	Add_Get(160,200,G_THAI,40,80,title);
	Add_Get(160,240,G_ENGLISH,40,80,filename);
	Read_Get();
	strtrim(title);
	strtrim(filename);
	Set_EditBKColor(old_tcol);
	Set_TColor(old_edbk);
	s_title(title);
	s_filename(filename);
}

