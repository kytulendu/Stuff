#include <stdio.h>
#include <egalib.h>
#include <thaivga.h>
#include <menu.h>

font fn[256];

#define COMMAND1 1
#define COMMAND2 2
#define COMMAND3 3
#define COMMAND4 4
#define COMMAND5 5
#define COMMAND6 6
#define COMMAND7 7
#define EXIT 100

MenuItem main_menu[] = {
	{"Menu 1",5,M_POPUP},
		{"Menu 2",5,COMMAND2},
		{"Menu 3",5,COMMAND3},
		{"Menu 4",5,COMMAND4},
		{"Menu 5",5,COMMAND5},
		{"",0,M_SEPARATOR},
		{"Menu 6",5,COMMAND6},
		{"",0,M_END},
	{"Menu 7",5,COMMAND7},
	{"Exit",0,EXIT},
	{"",0,M_END}};

int main()
{
	int mnu;
	Set_Mode(VM_GRAPHIC);
	if(Load_TFont(fn,"..\\font\\normal.fon")) {
		Set_Mode(VM_TEXT);
		exit(1);
	}
	Set_TColor(15);
	Set_TFont(fn);
	Disable_Menu(COMMAND4);
	Check_Menu(COMMAND5);
	do{
		mnu = Menu(0,0,main_menu);
		switch(mnu){
			case COMMAND5: if(Is_Check_Menu(COMMAND5))
							   UnCheck_Menu(COMMAND5);
						   else Check_Menu(COMMAND5);
			case COMMAND1:
			case COMMAND2:
			case COMMAND3:
			case COMMAND4:
			case COMMAND6:
			case COMMAND7:{
				char st[80];
				sprintf(st,"You select command %d",mnu);
				Out_ThaiV(0,200,st);
				Get_KB();
				Clear_Screen();
			}
	   }
	}while(mnu!=EXIT);
	Set_Mode(VM_TEXT);
	return mnu;
}