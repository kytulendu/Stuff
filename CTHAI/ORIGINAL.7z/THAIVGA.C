#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <io.h>
#include <string.h>
#include <dos.h>
#include <bios.h>
#include <ctype.h>
#include <mem.h>
#include <alloc.h>

#include "keyboard.h"

#define CHAR_LEN_X  8
#define CHAR_LEN_Y  20
#define FONT_LENGTH  256

#define VM_GRAPHIC 0x12
#define VM_TEXT    0x03

#define G_THAI    1
#define G_ENGLISH 2
#define G_NUM     3

#define RIGHT 0x01
#define LEFT  0x02
#define CTRL  0x04
#define ALT   0x08

typedef unsigned char BYTE;
typedef unsigned int  WORD;

#define LOWORD(l)    ((WORD)(l))
#define HIWORD(l)    ((WORD)(((DWORD)(l) >> 16) & 0xFFFF))
#define LOBYTE(w)    ((BYTE)(w))
#define HIBYTE(w)    ((BYTE)(((WORD)(w) >> 8) & 0xFF))

#define KEY_BUFF_SIZE 20

#define set_writecolor(x) outport(0x03c4, 0x0100 * x + 0x0002)
#define set_readplane(x)  outport(0x03ce, 0x0100 * x + 0x0004)

#define Clear_Screen() Solid_Box(0, 0, 639, 479, BLACK);

/* ---MENU----- */

#define M_POPUP     -1
#define M_END       -2
#define M_SEPARATOR -3

typedef struct {
    char *st;
    int hotkey;
    int com;
} MenuItem;

extern int max_check_menu, max_disable_menu;

int Is_Check_Menu(int com);
void Check_Menu(int com);
void UnCheck_Menu(int com);
int Is_Disable_Menu(int com);
void Disable_Menu(int com);
void UnDisable_Menu(int com);
void Set_Menu_Color(int normal, int normal_bk, int inverse, int inverse_bk, int disable);
int Menu(int x, int y, MenuItem mnu[]);
int Pull_Menu(int x,int y, int sp, MenuItem mnu[]);

/* ---------------- */

typedef struct {
    int x1, y1, x2, y2;
    unsigned char far *img[4];
} Screen;

Screen scr_ed[8];

int img_top = 0;

unsigned char far *scr = MK_FP(0xA000, 0000);

#if !defined(__COLORS)
#define __COLORS

enum COLORS {
    BLACK,                              /* dark colors */
    BLUE,
    GREEN,
    CYAN,
    RED,
    MAGENTA,
    BROWN,
    LIGHTGRAY,
    DARKGRAY,                           /* light colors */
    LIGHTBLUE,
    LIGHTGREEN,
    LIGHTCYAN,
    LIGHTRED,
    LIGHTMAGENTA,
    YELLOW,
    WHITE
};

#endif

#if !defined(__GRAPHICS_H)

enum putimage_ops { /* BitBlt operators for putimage */
    COPY_PUT,       /* MOV */
    XOR_PUT,        /* XOR */
    OR_PUT,         /* OR  */
    AND_PUT,        /* AND */
    NOT_PUT         /* NOT */
};

#endif

typedef unsigned char font[CHAR_LEN_Y];      /* One char font */

char tspace[256] = {
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
    0,0,0,0,0,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,
    1,0,1,1,0,0,0,0,0,0,0,1,1,1,1,1,
    1,1,1,1,1,1,1,0,0,0,0,0,0,0,1,1,
    1,1,1,1,1,1,1,1,1,1,1,1,0,0,0,0
};

font *default_tfont;

int default_tcolor = 0x0f;

extern char tspace[256];

char tlevel[] = {
    5,
    1,2,1,1,2,2,2,2,2,2,2,3,5,5,5,5,
    4,4,4,4,4,5,5,3,3,3,3,3,3,3,3,5
};

char _level_map[6][6] = {
    0,0,0,0,0,0,
    0,1,1,1,0,0,
    0,1,1,0,0,0,
    0,0,1,1,0,0,
    0,1,1,1,0,0,
    0,1,1,1,0,0
};

int edit_bk_color=1;

struct {
    int x, y, type, max_len, buf_len;
    char *buff;
    char old[80];
} *get_data;

int n_get = 0;

int _get = 0;

unsigned char _thai_kb[0x54] = {
    0x00,0x1B,0x00,0x2F,0x5F,0xC0,0xB6,0xD8,0xD6,0xA4,0xB5,0xA8,0xA2,0xAA,0x08,0x09,
    0xE6,0xE4,0xD3,0xBE,0xD0,0xD1,0xD5,0xC3,0xB9,0xC2,0xBA,0xC5,0x0D,0x00,0xBF,0xCB,
    0xA1,0xB4,0xE0,0xE9,0xE8,0xD2,0xCA,0xC7,0xA7,0x00,0x00,0x60,0xBC,0xBB,0xE1,0xCD,
    0xD4,0xD7,0xB7,0xC1,0xE3,0xBD,0x00,0x2A,0x00,0x20,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x37,0x38,0x39,0x2D,0x34,0x35,0x36,0x2B,0x31,
    0x32,0x33,0x30,0x2E
};

unsigned char _thai_kbs[0x54] = {
    0x00,0x1B,0x00,0xF1,0xF2,0xF3,0xF4,0xD9,0xDB,0xF5,0xF6,0xF7,0xF8,0xF9,0x08,0x09,
    0xF0,0x22,0xAE,0xB1,0xB8,0xEB,0xEA,0xB3,0xCF,0xAD,0xB0,0x2C,0x0D,0x00,0xC4,0xA6,
    0xAF,0xE2,0xAC,0xE7,0xEB,0xC9,0xC8,0xAB,0x2E,0x00,0x00,0x7E,0x28,0x29,0xA9,0xCE,
    0x25,0xEC,0x3F,0xB2,0xCC,0x3F,0x00,0x2A,0x00,0x20,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0xF7,0xF8,0xF9,0x2D,0xF4,0xF5,0xF6,0x2B,0xF1,
    0xF2,0xF3,0xF0,0x2E
};

int _thai_key = 1, _last_key = 0, _eng_only_key = 0, _num_only_key = 0;

int head_key = 0, tail_key = 0, key_buff[KEY_BUFF_SIZE];

void Set_Mode(int mode);
void Get_Mode();
int load_Tfont(font *fn, char *name);
int Thai_Len(unsigned char st[]);
int Thai_Hight();
int Thai_Width(unsigned char st[]);
void Set_TColor(int col);
int Get_TColor();
void Set_TFont(font *fn);
font *Get_TFont();
void Out_ThaiV(int x, int y, unsigned char st[]);
void Out_ChV(int x,int y,char ch);
void Rectangle(int x1,int y1,int x2,int y2,int col);
void Line(int x1, int y1, int x2, int y2, int col);
void Solid_Box(int x1, int y1, int x2, int y2, int col);

void SCANLINE(int start, int end, int raster, int color);
void OUT_CH(int x, int y, int col, int chr, int fn_seg, int fn_off);
void _LINE(int x1, int y1, int x2, int y2, int col);

void BITBLT(int X_Srs, int Y_Src, int X_Dst, int Y_Dst, int BWidth, int BHeight, int Fn);
void REMOVE_CURSOR();
void MOVE_CURSOR(int x, int y);
void Set_Cursor(int AND_Mask , int XOR_Mask, int BG_Color, int FG_Color);

void Set_EditBKColor(int col);
int Get_EditBKColor();
void Edit_Out(int x, int y, int start, int len, char *st);
void Line_Edit(int x, int y, int n, int max, unsigned char *st);
void Add_Get(int x, int y, int type, int max_len, int buf_len, char *buff);
void Read_Get();
void Show_Cursor(int x, int y);
int KB_Hit();
int Get_KB();
void Write_KB(int key);
int Get_LastKey();
void Beep();
int Get_ThaiKey();
void Set_ThaiKey(int i);
int Get_EngOnlyKey();
void Set_EngOnlyKey(int i);
int Alt2Chr(int key);
void Set_NumOnlyKey(int i);

void Save_Screen(int x1, int y1, int x2, int y2);
void Restore_Screen();
void Near_Save_Screen(int x1, int y1, int x2, int y2);
void Near_Restore_Screen();

void Show_KMITT_logo(int x, int y, char *path);

int Get_TLevel(unsigned char ch)
{
    if(ch <= 0xA0)
        return 5;
    if((ch > 0xA0)&&(ch < 0xCF))
        return 0;
    if(ch >= 0xF0)
        return 5;
    return tlevel[ch - 0xCF];
}

int Level_Map(int i, int j)
{
    return _level_map[i][j];
}

void Set_EditBKColor(int col)
{
    edit_bk_color = col;
}
int Get_EditBKColor()
{
    return edit_bk_color;
}

void Edit_Out(int x, int y, int start, int len, char *st)
{
    char temp[100];

    strcpy(temp, st);
    while(Thai_Len(temp) > start)
        temp[strlen(temp) - 1] = 0;
    strcpy(temp, st + strlen(temp));
    while(Thai_Len(temp) > len)
        temp[strlen(temp) - 1] = 0;
    Out_ThaiV(x, y, temp);
}

void Line_Edit(int x, int y, int n, int max, unsigned char *st)
{
    int cur_pos, start, index, ch, i;
    char temp[100];

    max--;
    strcpy(temp, st);
    index = strlen(st);
    if(Thai_Len(st) < n)
    {
        start = 0;
        cur_pos = Thai_Len(st);
    }
    else
    {
        start = 0;
        for(i = 0; Thai_Len(st + i) > n; i++)
            start += tspace[(unsigned char)st[i]];
        start++;
        cur_pos = n - 1;
    }
    Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
    Edit_Out(x, y, start, n, st);
    while(1)
    {
        Show_Cursor(x + cur_pos * CHAR_LEN_X, y);
        ch = Get_KB();
        if(_get)
            if((ch == KEY_UP) || (ch == KEY_DOWN) || (ch == KEY_ENTER) || (ch == KEY_ESC))
            {
                ch = KEY_ENTER;
                Write_KB(Get_LastKey());
            }
        if(ch > 0xFF)
            switch(ch)
            {
                case KEY_HOME :
                {
                    int old_start = start;
                    cur_pos = 0;
                    start = 0;
                    index = 0;
                    if(old_start != start)
                    {
                        Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                        Edit_Out(x, y, start, n, st);
                    }
                    break;
                }

                case KEY_END :
                {
                    int old_start = start;
                    index = strlen(st);
                    if(Thai_Len(st) < n)
                    {
                        start = 0;
                        cur_pos = Thai_Len(st);
                    }
                    else
                    {
                        start = 0;
                        for(i = 0; Thai_Len(st + i) > n; i++)
                            start += tspace[(unsigned char)st[i]];
                        start++;
                        cur_pos = n - 1;
                    }
                    if(old_start != start)
                    {
                        Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                        Edit_Out(x, y, start, n, st);
                    }
                    break;
                }

                case KEY_DEL :
                    if(index < strlen(st))
                    {
                        for(i = index; st[i] != 0; i++)
                            st[i] = st[i + 1];
                        while((tspace[(unsigned char)st[index]] == 0) && (index < strlen(st)))
                            for(i = index; st[i] != 0; i++)
                                st[i] = st[i + 1];
                        Solid_Box(x + cur_pos* CHAR_LEN_X, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                        Edit_Out(x + cur_pos * CHAR_LEN_X, y, start + cur_pos, n - cur_pos, st);
                    }
                    else
                        Beep();
                    break;

                case KEY_LEFT :
                    if(index > 0)
                    {
                        index--;
                        if(index > 0)
                            while(tspace[(unsigned char)st[index]] == 0)
                                index--;
                        if(cur_pos > 0)
                            cur_pos--;
                        else
                        {
                            start--;
                            Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                            Edit_Out(x, y, start, n, st);
                        }
                    }
                    break;

                case KEY_RIGHT :
                    if((index < max) && (index < strlen(st)))
                    {
                        index++;
                        while(tspace[(unsigned char)st[index]] == 0)
                            index++;
                        if(cur_pos < n - 1)
                            cur_pos++;
                        else
                        {
                            start++;
                            Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                            Edit_Out(x, y, start, n, st);
                        }
                    }
                    break;

                case KEY_CTRL_LEFT :
                {
                    int score = 0;
                    do if(index > 0)
                    {
                        index--;
                        if(index > 0)
                            while(tspace[(unsigned char)st[index]] == 0)
                                index--;
                        if(cur_pos > 0)
                            cur_pos--;
                        else
                        {
                            start--;
                            score = 1;
                        }
                    }
                    while((index > 0) && ((st[index] <= ' ') || (st[index - 1] != ' ')));
                    if(score)
                    {
                        Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                        Edit_Out(x, y, start, n, st);
                    }
                    break;
                }

                case KEY_CTRL_RIGHT :
                {
                    int score = 0;
                    do if((index < max) && (index < strlen(st)))
                    {
                        index++;
                        while(tspace[(unsigned char)st[index]] == 0)
                            index++;
                        if(cur_pos < n - 1)
                            cur_pos++;
                        else
                        {
                            start++;
                            score = 1;
                        }
                    }
                    while((index < strlen(st)) && ((st[index] != ' ') || (st[index - 1] <= ' ')));
                    if(score)
                    {
                        Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                        Edit_Out(x, y, start, n, st);
                    }
                    break;
                }
            }
        else
            switch(ch)
            {
                case KEY_ENTER :
                    return;

                case KEY_ESC :
                    strcpy(st, temp);
                    cur_pos = 0;
                    start = 0;
                    index = 0;
                    Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                    Edit_Out(x, y, start, n, st);
                    return;

                case KEY_BACKSPACE :
                    if(index > 0)
                    {
                        int space;
                        space = tspace[(unsigned char)st[index - 1]];
                        for(i = index - 1; st[i] != 0; i++)
                            st[i] = st[i + 1];
                        index--;
                        if(cur_pos > 0)
                        {
                            cur_pos -= space;
                            Solid_Box(x + (cur_pos - 1 + space) * CHAR_LEN_X, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                            Edit_Out(x + (cur_pos - 1 + space) * CHAR_LEN_X, y, start + (cur_pos - 1 + space), n - (cur_pos - 1 + space), st);
                        }
                        else
                        {
                            start -= space;
                            Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                            Edit_Out(x, y, start, n, st);
                        }
                    }
                    else
                        Beep();
                    break;

                default :
                    if(strlen(st) >= max)
                    {
                        Beep();
                        break;
                    }
                    if((ch >= 32) && (index < max))
                    {
                        int space, err = 0;
                        if(index == 0)
                            switch(Get_TLevel(ch))
                            {
                                case 1:
                                case 2:
                                case 3:
                                    err = 1;
                                    break;
                            }
                        else
                            err = Level_Map(Get_TLevel(st[index - 1]), Get_TLevel(ch));
                        if(err)
                        {
                            Beep();
                            break;
                        }
                        space = tspace[ch];
                        for(i = strlen(st); i >= index; i--)
                            st[i + 1] = st[i];
                        st[index] = ch;
                        index++;
                        if(cur_pos < n - 1)
                        {
                            Solid_Box(x + (cur_pos - 1 + space) * CHAR_LEN_X, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                            Edit_Out(x + (cur_pos - 1 + space) * CHAR_LEN_X, y, start + (cur_pos - 1 + space), n - (cur_pos - 1 + space), st);
                            cur_pos+=space;
                        }
                        else
                        {
                            start += space;
                            Solid_Box(x, y, x + n * CHAR_LEN_X, y + CHAR_LEN_Y, edit_bk_color);
                            Edit_Out(x, y, start, n, st);
                        }
                    }
            }
    }
}

void Add_Get(int x, int y, int type, int max_len, int buf_len, char *buff)
{
    if(n_get == 0)
        get_data = malloc(sizeof(*get_data));
    else
        get_data = realloc(get_data, sizeof(*get_data) * (n_get + 1));
    if(get_data == NULL)
    {
        printf("Not enough memory");
        exit(1);
    }
    get_data[n_get].x = x;
    get_data[n_get].y = y;
    get_data[n_get].type = type;
    get_data[n_get].max_len = max_len;
    get_data[n_get].buf_len = buf_len;
    get_data[n_get].buff = buff;
    strcpy(get_data[n_get].old, buff);
    n_get++;
}

void Read_Get()
{
    int cur = 0, ch = 0, old_engonlykey = Get_EngOnlyKey(), old_numonlykey = Get_NumOnlyKey(), i;

    if(n_get == 0)
        return;
    for(i = 0; i < n_get; i++)
    {
        Write_KB(KEY_ESC);
        Line_Edit(get_data[i].x, get_data[i].y, get_data[i].max_len, get_data[i].buf_len, get_data[i].buff);
    }
    _get = 1;
    Set_EngOnlyKey(0);
    Set_NumOnlyKey(0);
    do
    {
        switch(get_data[cur].type)
        {
            case G_THAI:
                Line_Edit(get_data[cur].x, get_data[cur].y, get_data[cur].max_len, get_data[cur].buf_len, get_data[cur].buff);
                break;
            case G_ENGLISH:
                Set_EngOnlyKey(1);
                Line_Edit(get_data[cur].x, get_data[cur].y, get_data[cur].max_len, get_data[cur].buf_len, get_data[cur].buff);
                Set_EngOnlyKey(0);
                break;
            case G_NUM:
                Set_NumOnlyKey(1);
                Line_Edit(get_data[cur].x, get_data[cur].y, get_data[cur].max_len, get_data[cur].buf_len, get_data[cur].buff);
                Set_NumOnlyKey(0);
                break;
        }
        ch = Get_KB();
        switch(ch)
        {
            case KEY_UP:
                if(cur > 0)
                    cur--;
                else
                    cur = n_get - 1;
                break;
            case KEY_DOWN:
                cur++;
                if(cur >= n_get)
                    cur = 0;
                break;
        }
    }
    while((ch != KEY_ENTER) && (ch != KEY_ESC));
    if(ch == KEY_ESC)
        for(i = 0; i < n_get; i++)
            strcpy(get_data[i].buff, get_data[i].old);
    free(get_data);
    Set_EngOnlyKey(old_engonlykey);
    Set_NumOnlyKey(old_numonlykey);
    _get = 0;
    n_get = 0;
}

void Write_KB(int key)
{
    if((head_key + 1) % KEY_BUFF_SIZE != tail_key)
    {
        key_buff[head_key] = key;
        head_key = (head_key+  1) % KEY_BUFF_SIZE;
    }
}

int KB_Hit()
{
    if(head_key != tail_key)
        return 1;
    return !(_bios_keybrd(_KEYBRD_READY) == 0);
}

int Get_KB()
{
    int key, modifiers;

    if(head_key != tail_key)
    {
        key = key_buff[tail_key];
        tail_key = (tail_key + 1) % KEY_BUFF_SIZE;
        _last_key = key;
        return key;
    }
    key = _bios_keybrd(_KEYBRD_READ);
    if((HIBYTE(key) == 0x29) && (!_eng_only_key) && (!_num_only_key))
    {
       _thai_key = !_thai_key;
       return 0;
    }

    if(LOBYTE(key) != 0)
    {
        if(_num_only_key)
        {
            if(isdigit(LOBYTE(key)) || (LOBYTE(key) == KEY_BACKSPACE) || (LOBYTE(key) == KEY_ENTER) || (LOBYTE(key) == KEY_ESC))
                return(_last_key = LOBYTE(key));
            else
                return 0;
        }
        if(_thai_key && (LOBYTE(key) > 32) && (!_eng_only_key))
        {
            modifiers = _bios_keybrd(_KEYBRD_SHIFTSTATUS);
            if((modifiers & RIGHT) || (modifiers & LEFT))
            {
                if(_thai_kbs[HIBYTE(key)] == 0xDB)
                {
                    Write_KB(0xE9);
                    return (_last_key = 0xD1);
                }
                return (_last_key = _thai_kbs[HIBYTE(key)]);
            }
            return (_last_key = _thai_kb[HIBYTE(key)]);
        }
        else
            return (_last_key = LOBYTE(key));
    }
    return (_last_key = key);
}

int Get_LastKey()
{
    return _last_key;
}

int Get_ThaiKey()
{
    return _thai_key;
}

void Set_ThaiKey(int i)
{
    _thai_key = i;
}

int Get_EngOnlyKey()
{
    return _eng_only_key;
}

void Set_EngOnlyKey(int i)
{
    _eng_only_key = i;
}

int Get_NumOnlyKey()
{
    return _num_only_key;
}

void Set_NumOnlyKey(int i)
{
    _num_only_key = i;
}

void Show_Cursor(int x, int y)
{
    static char t_and_mask[] =
    {
        0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF,
        0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF, 0x00,0xFF,
        0x00,0xFF, 0x00,0xFF, 0x00,0xFF, 0x00,0xFF,
        0x00,0xFF, 0x00,0xFF, 0x00,0xFF, 0x00,0xFF
    };

    static char t_xor_mask[] = {
        0x00,0x00, 0x00,0x00, 0x00,0x00, 0x00,0x00,
        0x00,0x00, 0x00,0x00, 0x00,0x00, 0xFF,0x00,
        0x81,0x00, 0x81,0x00, 0xC7,0x00, 0xC7,0x00,
        0xC7,0x00, 0xC7,0x00, 0xC7,0x00, 0xFF,0x00
    };

    static char e_and_mask[] = {
        0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF,
        0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF, 0x00,0xFF,
        0x00,0xFF, 0x00,0xFF, 0x00,0xFF, 0x00,0xFF,
        0x00,0xFF, 0x00,0xFF, 0x00,0xFF, 0x00,0xFF
    };

    static char e_xor_mask[] = {
        0x00,0x00, 0x00,0x00, 0x00,0x00, 0x00,0x00,
        0x00,0x00, 0x00,0x00, 0x00,0x00, 0xFF,0x00,
        0x81,0x00, 0x81,0x00, 0x8F,0x00, 0x83,0x00,
        0x8F,0x00, 0x81,0x00, 0x81,0x00, 0xFF,0x00
    };

    static char n_and_mask[] = {
        0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF,
        0xFF,0xFF, 0xFF,0xFF, 0xFF,0xFF, 0x00,0xFF,
        0x00,0xFF, 0x00,0xFF, 0x00,0xFF, 0x00,0xFF,
        0x00,0xFF, 0x00,0xFF, 0x00,0xFF, 0x00,0xFF
    };

    static char n_xor_mask[] = {
        0x00,0x00, 0x00,0x00, 0x00,0x00, 0x00,0x00,
        0x00,0x00, 0x00,0x00, 0x00,0x00, 0xFF,0x00,
        0x99,0x00, 0x89,0x00, 0x81,0x00, 0x81,0x00,
        0x81,0x00, 0x91,0x00, 0x99,0x00, 0xFF,0x00
    };

    int  show = 1;
    long tm, otm;

    otm = biostime(0, 0L);
    if(_num_only_key)
        SET_CURSOR(n_and_mask, n_xor_mask, 0, 15);
    else
        if(_thai_key && !_eng_only_key)
            SET_CURSOR(t_and_mask, t_xor_mask, 0, 15);
        else
            SET_CURSOR(e_and_mask, e_xor_mask, 0, 15);
    MOVE_CURSOR(x, y);
    while(!KB_Hit())
    {
        tm = biostime(0, 0L);
        if(!show && (tm - otm) >= 5)
        {
            show = 1;
            otm = tm;
            MOVE_CURSOR(x, y);
        }
        if(show && (tm - otm) >= 5)
        {
            show = 0;
            otm = tm;
            REMOVE_CURSOR();
        }
    }
    if(show)
        REMOVE_CURSOR();
}

void Beep()
{
    long tm;
    sound(2000);
    tm = biostime(0, 0L);
    tm += 1;
    while(biostime(0, 0L) <= tm);
    nosound();
}

int Alt2Chr(int key)
{
    static int chkey[] = {
        'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', 0, 0, 0, 0,
        'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', 0, 0, 0, 0, 0,
        'Z', 'X', 'C', 'V', 'B', 'N', 'M'
    };
    if((key < KEY_ALT_Q) || (key > KEY_ALT_M))
        return 0;
    return chkey[HIBYTE(key - KEY_ALT_Q)];
}

void Set_Mode(int mode)
{

    union REGS regs;

    regs.h.ah = 0;                      /* set BIOS function number */
    regs.h.al = mode;                   /* set video mode number */
    int86(0x10, &regs, &regs);          /* set video mode */
}

/*
   Load Font 256 char into *name

   return 0 if succsessful
   return -1 if error
*/
int Load_TFont(font *fn, char *name)
{
    int fi, i;
    font buff;
    if((fi = open(name, O_RDONLY | O_BINARY)) == -1)
        return(-1);
    for(i = 0; i < FONT_LENGTH; i++)
    {
        read(fi, &(buff), CHAR_LEN_Y);
        movedata(FP_SEG(buff), FP_OFF(buff), FP_SEG(fn[i]), FP_OFF(fn[i]), sizeof(font));
    }
    close(fi);
    return 0;
}

void Set_TFont(font *fn)
{
    default_tfont = fn;
}

font *Get_TFont()
{
    return default_tfont;
}

void Set_TColor(int col)
{
    default_tcolor = col;
}

int Get_TColor()
{
    return default_tcolor;
}

int Thai_Hight()
{
    return CHAR_LEN_Y;
}

int Thai_Width(unsigned char st[])
{
    return Thai_Len(st) * CHAR_LEN_X;
}

int Thai_Len(unsigned char st[])
{
    int i, l = 0;

    for(i = 0; st[i]; i++)
       l += tspace[st[i + 1]];

    return l;
}

void Out_ThaiV(int x, int y, unsigned char st[])
{
    int i, j = 1;

    if(st == NULL)
        return;
    for(i = 0; st[i]; i++)
    {
       OUT_CH(x * j, y, default_tcolor, st[i], FP_SEG(default_tfont), FP_OFF(default_tfont));
       x += tspace[st[i + 1]] * CHAR_LEN_X;
    }
}

void Out_ChV(int x, int y, char ch)
{
    OUT_CH(x, y, default_tcolor, ch, FP_SEG(default_tfont), FP_OFF(default_tfont));
}

#define _iswap(a, b) \
{                    \
    int i;           \
    i = *a;          \
    *a = *b;         \
    *b = i;          \
}

void Solid_Box(int x1, int y1, int x2, int y2, int col)
{
    int i;
    if(x1 > x2)
        _iswap(&x1, &x2);
    if(y1 > y2)
        _iswap(&y1, &y2);
    for(i = y1; i <= y2; i++)
    {
        SCANLINE(x1, x2, i, col);
    }
}

void Line(int x1, int y1, int x2, int y2, int col)
{
    if(x1 > x2)
        _iswap(&x1, &x2);
    if(y1 > y2)
        _iswap(&y1, &y2);
    if(y1 == y2)
        SCANLINE(x1, x2, y1, col);
    else
        _LINE(x1, y1, x2, y2, col);
}

void Rectangle(int x1, int y1, int x2, int y2, int col)
{
    Line(x1, y1, x1, y2, col);
    Line(x2, y1, x2, y2, col);
    Line(x1, y1, x2, y1, col);
    Line(x1, y2, x2, y2, col);
}

void Save_Screen(int x1, int y1, int x2, int y2)
{
    register int x, y;
    int plane;
    if(img_top >= 7)
        return;
    if(y1 > y2)
        _iswap(&y1, &y2);
    if(x1 > x2)
        _iswap(&x1, &x2);
    x1 /= 8;
    x2 /= 8;
    if(scr_ed[img_top].img[0] != NULL)
        return;
    scr_ed[img_top].x1 = x1;
    scr_ed[img_top].x2 = x2;
    scr_ed[img_top].y1 = y1;
    scr_ed[img_top].y2 = y2;
    for(plane = 0; plane < 4; plane++)
    {
        if((scr_ed[img_top].img[plane] = (unsigned char far *)farmalloc((x2 + 1 - x1) * (y2 + 1 - y1))) == NULL)
        {
            printf("Not enough memory");
            exit(1);
        }
        set_readplane(plane);
        for(y = y1; y <= y2; y++)
            for(x = x1; x <= x2; x++)
                scr_ed[img_top].img[plane][(x - x1) + (y - y1) * (x2 - x1 + 1)]=  scr[x + y * 80];
    }
    img_top += 1;
}

void Restore_Screen()
{
    register int x, y;
    int x1, y1, x2, y2;
    int plane;

    if(img_top < 0)
        return;
    img_top -=1;
    x1 = scr_ed[img_top].x1;
    x2 = scr_ed[img_top].x2;
    y1 = scr_ed[img_top].y1;
    y2 = scr_ed[img_top].y2;
    for(plane = 0; plane < 4; plane++)
    {
        switch(plane)
        {
            case 0 : set_writecolor(1);
                break;
            case 1 : set_writecolor(2);
                break;
            case 2 : set_writecolor(4);
                break;
            case 3 : set_writecolor(8);
                break;
        }
        for(y = y1; y <= y2; y++)
            for(x = x1;x<=x2;x++)
            scr[x + y * 80] = scr_ed[img_top].img[plane][(x - x1) + (y - y1) * (x2 - x1 + 1)];
        farfree(scr_ed[img_top].img[plane]);
        scr_ed[img_top].img[plane] = NULL;
    }
    set_writecolor(15);
}

void Near_Save_Screen(int x1, int y1, int x2, int y2)
{
    register int x, y;
    int plane;
    if(img_top >= 7)
        return;
    if(y1 > y2)
        _iswap(&y1, &y2);
    if(x1 > x2)
        _iswap(&x1, &x2);
    x1 /= 8;
    x2 /= 8;
    if(scr_ed[img_top].img[0] != NULL)
        return;
    scr_ed[img_top].x1 = x1;
    scr_ed[img_top].x2 = x2;
    scr_ed[img_top].y1 = y1;
    scr_ed[img_top].y2 = y2;
    for(plane = 0; plane < 4; plane++)
    {
        if((scr_ed[img_top].img[plane] = (unsigned char *)malloc((x2 + 1 - x1) * (y2 + 1 - y1))) == NULL)
        {
            printf("Not enough memory");
            exit(1);
        }
        set_readplane(plane);
        for(y = y1; y <= y2; y++)
            for(x = x1; x <= x2; x++)
                scr_ed[img_top].img[plane][(x - x1) + (y - y1) * (x2 - x1 + 1)] = scr[x + y * 80];
    }
    img_top += 1;
}

void Near_Restore_Screen()
{
    register int x, y;
    int x1, y1, x2, y2;
    int plane;

    if(img_top < 0)
        return;
    img_top -= 1;
    x1=scr_ed[img_top].x1;
    x2=scr_ed[img_top].x2;
    y1=scr_ed[img_top].y1;
    y2=scr_ed[img_top].y2;
    for(plane = 0; plane < 4; plane++)
    {
        switch(plane)
        {
            case 0 : set_writecolor(1);
                break;
            case 1 : set_writecolor(2);
                break;
            case 2 : set_writecolor(4);
                break;
            case 3 : set_writecolor(8);
                break;
        }
        for(y = y1; y <= y2; y++)
            for(x = x1; x <= x2; x++)
                scr[x + y * 80] = scr_ed[img_top].img[plane][(x - x1) + (y - y1) * (x2 - x1 + 1)];
        free((unsigned char *)scr_ed[img_top].img[plane]);
        scr_ed[img_top].img[plane] = NULL;
    }
    set_writecolor(15);
}

/* ======================================= */

int menu_pt = 0;
int menu_slide = 0;
int *_check_menu = NULL, n_check = 0;
int *_disable_menu = NULL, n_disable = 0;
int max_check_menu = 5, max_disable_menu = 5;
char check_st[] = "�";

int Is_Check_Menu(int com)
{
    int i;
    for(i = 0; i < n_check; i++)
        if(_check_menu[i] == com)
            return 1;
    return 0;
}

void Check_Menu(int com)
{
    if(n_check == 0)
    {
        _check_menu = calloc(max_check_menu, sizeof(*_check_menu));
        n_check = 1;
        _check_menu[0] = com;
    }
    else
    {
        if(Is_Check_Menu(com))
            return;
        if(n_check >= max_check_menu)
            return;
        _check_menu[n_check] = com;
        n_check++;
    }
}

void UnCheck_Menu(int com)
{
    int i;
    if(!Is_Check_Menu(com))
        return;
    for(i = 0; i < n_check; i++)
        if(_check_menu[i] == com)
            break;
    memcpy(_check_menu + i, _check_menu + i + 1, (n_check - i - 1) * sizeof(int));
    n_check--;
    if(n_check == 0)
        free(_check_menu);
}

int Is_Disable_Menu(int com)
{
    int i;
    for(i = 0; i < n_disable; i++)
        if(_disable_menu[i] == com)
            return 1;
    return 0;
}

void Disable_Menu(int com)
{
    if(n_disable == 0)
    {
        _disable_menu = calloc(max_disable_menu, sizeof(*_disable_menu));
        n_disable = 1;
        _disable_menu[0] = com;
    }
    else
    {
        if(Is_Disable_Menu(com))
            return;
        if(n_disable >= max_disable_menu)
            return;
        _disable_menu[n_disable] = com;
        n_disable++;
    }
}

void UnDisable_Menu(int com)
{
    int i;
    if(!Is_Disable_Menu(com))
        return;
    for(i = 0; i < n_disable; i++)
        if(_disable_menu[i] == com)
            break;
    memcpy(_disable_menu + i, _disable_menu + i + 1, (n_disable - i - 1) * sizeof(int));
    n_disable--;
    if(n_disable == 0)
        free(_disable_menu);
}

void go_next_menu(MenuItem mnu[])
{
    if(mnu[menu_pt].com != M_POPUP)
        menu_pt++;
    else
    {
        int level = 1;
        for(menu_pt++; level != 0; menu_pt++)
            if(mnu[menu_pt].com == M_POPUP)
                level++;
            else
                if(mnu[menu_pt].com == M_END)
                    level--;
    }
}

void go_before_menu(MenuItem mnu[])
{
    menu_pt--;
    if(mnu[menu_pt].com == M_END)
    {
        int level = 1;
        for(menu_pt--; level != 0; menu_pt--)
            if(mnu[menu_pt].com == M_END)
                level++;
            else
                if(mnu[menu_pt].com == M_POPUP)
                    level--;
        menu_pt++;
    }
}

int nb_color = WHITE;
int n_color  = BLACK;
int i_color  = MAGENTA;
int ib_color = YELLOW;
int d_color  = LIGHTGRAY;

void Set_Menu_Color(int normal, int normal_bk, int inverse, int inverse_bk, int disable)
{
    nb_color = normal_bk;
    n_color  = normal;
    i_color  = inverse;
    ib_color = inverse_bk;
    d_color  = disable;
}

int Menu(int x, int y, MenuItem mnu[])
{
    int width = 0, hight = Thai_Hight(), i, ch, old_tcolor = Get_TColor(), ret = 0, n;
    int old_eng_key = Get_EngOnlyKey();
    char st[80], stc[2];

    Set_EngOnlyKey(1);

    for(menu_pt = i = 0; mnu[menu_pt].com != M_END; i++, go_next_menu(mnu))
    {
        if(width < Thai_Width(mnu[menu_pt].st))
            width = Thai_Width(mnu[menu_pt].st);
    }
    width += 16;
    n = i;
    Save_Screen(x - 1, y - 1, x + width + 1, y + i * hight + 1);
    Rectangle(x, y, x + width + 1, y + n * hight + 1, d_color);
    Rectangle(x - 1, y - 1, x + width, y + n * hight, n_color);
    for(menu_pt = i = 0; mnu[menu_pt].com != M_END; i++, go_next_menu(mnu))
    {
        Solid_Box(x, y + i * hight, x + width, y + (i + 1) * hight - 1, nb_color);
        if(mnu[menu_pt].com == M_SEPARATOR)
        {
            int yy = y + i * hight + hight / 2;
            Line(x - 1, yy, x + width, yy, n_color);
        }
        else
        {
            Set_TColor(n_color);
            if(Is_Disable_Menu(mnu[menu_pt].com))
                Set_TColor(d_color);
            Out_ThaiV(x + 8, y + i * hight, mnu[menu_pt].st);
            if(Is_Check_Menu(mnu[menu_pt].com))
                Out_ThaiV(x, y + i * hight, check_st);
            if(mnu[menu_pt].com == M_POPUP)
                Out_ThaiV(x + width - 8, y + i * hight, ">");
            if(mnu[menu_pt].hotkey >= 0)
            {
                strcpy(st, mnu[menu_pt].st);
                st[mnu[menu_pt].hotkey] = 0;
                stc[0] = mnu[menu_pt].st[mnu[menu_pt].hotkey];
                stc[1] = 0;
                Set_TColor(i_color);
                Out_ThaiV(x + 8 + 8 * Thai_Len(st), y + i * hight, stc);
            }
        }
    }
    i = 0;
    ch = 0;
    menu_pt = 0;
    while((mnu[menu_pt].com == M_SEPARATOR) || (Is_Disable_Menu(mnu[menu_pt].com)))
    {
        go_next_menu(mnu);
        i++;
        if(mnu[menu_pt].com == M_END)
        {
            Write_KB(KEY_ESC);
            go_before_menu(mnu);
            i--;
            break;
        }
    }
    do
    {
        Solid_Box(x, y + i * hight, x + width, y + (i + 1) * hight - 1, ib_color);
        Set_TColor(i_color);
            if(mnu[menu_pt].com==M_SEPARATOR)
            {
                int yy = y + i * hight + hight / 2;
                Line(x - 1, yy, x + width, yy, n_color);
            }
            else
            {
                if(Is_Disable_Menu(mnu[menu_pt].com))
                    Set_TColor(d_color);
                Out_ThaiV(x + 8, y + i * hight, mnu[menu_pt].st);
                if(Is_Check_Menu(mnu[menu_pt].com))
                    Out_ThaiV(x, y + i * hight, check_st);
                if(mnu[menu_pt].com == M_POPUP)
                    Out_ThaiV(x + width - 8, y + i * hight, ">");
                if(mnu[menu_pt].hotkey >= 0)
                {
                    strcpy(st, mnu[menu_pt].st);
                    st[mnu[menu_pt].hotkey] = 0;
                    stc[0] = mnu[menu_pt].st[mnu[menu_pt].hotkey];
                    stc[1] = 0;
                    Set_TColor(i_color);
                    Out_ThaiV(x + 8 + 8 * Thai_Len(st), y + i * hight, stc);
                }
            }
        ch = Get_KB();
        if(menu_slide && (Alt2Chr(ch) != 0))
        {
            Write_KB(KEY_ESC);
            Write_KB(ch);
        }

        Solid_Box(x, y + i * hight, x + width, y + (i + 1) * hight - 1, nb_color);
        Set_TColor(n_color);
        if(mnu[menu_pt].com == M_SEPARATOR)
        {
            int yy = y + i * hight + hight / 2;
            Line(x - 1, yy, x + width, yy, n_color);
        }
        else
        {
            if(Is_Disable_Menu(mnu[menu_pt].com))
                Set_TColor(d_color);
            Out_ThaiV(x + 8, y + i * hight, mnu[menu_pt].st);
            if(Is_Check_Menu(mnu[menu_pt].com))
                Out_ThaiV(x, y + i * hight, check_st);
            if(mnu[menu_pt].com == M_POPUP)
                Out_ThaiV(x + width - 8, y + i * hight, ">");
            if(mnu[menu_pt].hotkey>=0)
            {
                strcpy(st, mnu[menu_pt].st);
                st[mnu[menu_pt].hotkey] = 0;
                stc[0] = mnu[menu_pt].st[mnu[menu_pt].hotkey];
                stc[1] = 0;
                Set_TColor(i_color);
                Out_ThaiV(x + 8 + 8 * Thai_Len(st), y + i * hight, stc);
            }
        }

        switch(ch)
        {
            case KEY_UP :
k_up:
                if(i > 0)
                {
                    go_before_menu(mnu);
                    i--;
                }
                else
                    if(i == 0)
                    {
                        i = n - 1;
                        while(mnu[menu_pt].com != M_END)
                            go_next_menu(mnu);
                        go_before_menu(mnu);
                    }
                    if((mnu[menu_pt].com == M_SEPARATOR) || (Is_Disable_Menu(mnu[menu_pt].com)))
                        goto k_up;
                    break;

            case KEY_DOWN :
k_dn:
                go_next_menu(mnu);
                i++;
                if(mnu[menu_pt].com == M_END)
                {
                    i = 0;
                    menu_pt = 0;
                }
                if((mnu[menu_pt].com == M_SEPARATOR) || (Is_Disable_Menu(mnu[menu_pt].com)))
                    goto k_dn;
                break;

            case KEY_RIGHT :
                if(mnu[menu_pt].com == M_POPUP)
                    Write_KB(KEY_ENTER);
                else
                    if(menu_slide)
                    {
                        ch = KEY_ESC;
                    }
                break;

            case KEY_LEFT  :
                if(menu_slide)
                {
                    ch = KEY_ESC;
                }
                break;

            case KEY_ENTER :
                {
                    int old_menu_pt = menu_pt, old_i = i;
                    if(mnu[menu_pt].com == M_POPUP)
                    {
                        ret = Menu(x + width, y + i * hight, mnu + menu_pt + 1);
                        Set_TColor(n_color);
                        menu_pt = old_menu_pt;
                        i = old_i;
                        if(ret == 0)
                        ch = 0;
                        if(menu_slide && (Get_LastKey() == KEY_RIGHT))
                        {
                            ch = KEY_ESC;
                            ret = 0;
                        }
                    }
                }
                break;

            default:
                {
                    int old_menu_pt = menu_pt, old_i = i;
                    ch = toupper(ch);
                    if(isalnum(ch))
                    {
                        menu_pt = i = 0;
                        while(mnu[menu_pt].com != M_END)
                        {
                            if((ch==toupper(mnu[menu_pt].st[mnu[menu_pt].hotkey]))
                                && (mnu[menu_pt].com != M_SEPARATOR)
                                && !Is_Disable_Menu(mnu[menu_pt].com))
                            {
                                Write_KB(KEY_ENTER);
                                old_menu_pt = menu_pt;
                                old_i = i;
                                break;
                            }
                            go_next_menu(mnu);
                            i++;
                        }
                    }
                    menu_pt = old_menu_pt;
                    i = old_i;
                }
        }
    }
    while((ch != KEY_ENTER) && (ch != KEY_ESC));

    Set_TColor(old_tcolor);
    Set_EngOnlyKey(old_eng_key);
    Restore_Screen();
    if(ch == KEY_ESC)
        return 0;
    if(mnu[menu_pt].com == M_POPUP)
        return ret;
    return(mnu[menu_pt].com);
}

int Pull_Menu(int x, int y, int sp, MenuItem mnu[])
{
    int width = 0, hight = Thai_Hight(), i, ch, old_tcolor = Get_TColor(), ret = 0, n;
    int xx[15];
    int old_eng_key = Get_EngOnlyKey();
    char st[80], stc[2];

    Set_EngOnlyKey(1);

    for(menu_pt = i = 0; mnu[menu_pt].com != M_END; i++, go_next_menu(mnu))
    {
        if(mnu[menu_pt].com != M_END)
            width += Thai_Width(mnu[menu_pt].st) + sp;
    }
    n = i;
    Set_TColor(n_color);
    xx[0] = x;
    width = x;
    for(menu_pt = i = 0; mnu[menu_pt].com != M_END; i++, go_next_menu(mnu))
    {
        if(mnu[menu_pt].com != M_END)
            xx[i + 1] = (width += Thai_Width(mnu[menu_pt].st) + sp);
        Solid_Box(xx[i], y, xx[i] + Thai_Width(mnu[menu_pt].st) + 16, y + hight - 1, nb_color);
        Out_ThaiV(xx[i] + 8, y, mnu[menu_pt].st);
        if(mnu[menu_pt].hotkey >= 0)
        {
            strcpy(st,mnu[menu_pt].st);
            st[mnu[menu_pt].hotkey] = 0;
            stc[0] = mnu[menu_pt].st[mnu[menu_pt].hotkey];
            stc[1] = 0;
            Set_TColor(i_color);
            Out_ThaiV(xx[i] + 8 + 8 * Thai_Len(st), y, stc);
            Set_TColor(n_color);
        }
    }
    i = 0;
    ch = 0;
    menu_pt = 0;
    do
    {
        if(!KB_Hit())
        {
            Solid_Box(xx[i], y, xx[i] + Thai_Width(mnu[menu_pt].st) + 16, y + hight - 1, ib_color);
            Set_TColor(i_color);
            Out_ThaiV(xx[i] + 8, y, mnu[menu_pt].st);
            if(mnu[menu_pt].hotkey >= 0)
            {
                strcpy(st, mnu[menu_pt].st);
                st[mnu[menu_pt].hotkey] = 0;
                stc[0] = mnu[menu_pt].st[mnu[menu_pt].hotkey];
                stc[1] = 0;
                Set_TColor(i_color);
                Out_ThaiV(xx[i] + 8 + 8 * Thai_Len(st), y, stc);
            }
        }

        ch = Get_KB();
        if(Alt2Chr(ch) != 0)
            ch = Alt2Chr(ch);

        Solid_Box(xx[i], y, xx[i] + Thai_Width(mnu[menu_pt].st) + 16, y + hight - 1, nb_color);
        Set_TColor(n_color);
        Out_ThaiV(xx[i] + 8, y, mnu[menu_pt].st);
        if(mnu[menu_pt].hotkey >= 0)
        {
            strcpy(st, mnu[menu_pt].st);
            st[mnu[menu_pt].hotkey] = 0;
            stc[0] = mnu[menu_pt].st[mnu[menu_pt].hotkey];
            stc[1] = 0;
            Set_TColor(i_color);
            Out_ThaiV(xx[i] + 8 + 8 * Thai_Len(st), y, stc);
        }

        switch(ch)
        {
            case KEY_LEFT :
                if(i > 0)
                {
                    go_before_menu(mnu);
                    i--;
                }
                else
                    if(i == 0)
                    {
                          i = n - 1;
                          while(mnu[menu_pt].com != M_END)
                              go_next_menu(mnu);
                          go_before_menu(mnu);
                    }
                break;

            case KEY_RIGHT :
                go_next_menu(mnu);
                i++;
                    if(mnu[menu_pt].com == M_END)
                    {
                        i = 0;
                        menu_pt = 0;
                    }
                break;

            case KEY_DOWN :
                Write_KB(KEY_ENTER);
                break;

            case KEY_ENTER :
                {
                    int old_menu_pt = menu_pt, old_i = i;
                    if(mnu[menu_pt].com == M_POPUP)
                    {
                        menu_slide = 1;
                        ret=Menu(xx[i], y + hight + 1, mnu + menu_pt + 1);
                        menu_slide = 0;
                        Set_TColor(n_color);
                        menu_pt = old_menu_pt;
                        i = old_i;
                        if(ret == 0)
                            ch=0;
                        switch(Get_LastKey())
                        {
                            case KEY_LEFT :
                                Write_KB(KEY_LEFT);
                                Write_KB(KEY_ENTER);
                                break;

                            case KEY_RIGHT :
                                Write_KB(KEY_RIGHT);
                                Write_KB(KEY_ENTER);
                                break;
                        }
                    }
                }
                break;

            default:
                {
                    int old_menu_pt = menu_pt, old_i = i;
                    ch = toupper(ch);
                    if(isalnum(ch))
                    {
                        menu_pt = i = 0;
                        while(mnu[menu_pt].com != M_END)
                        {
                            if((ch == toupper(mnu[menu_pt].st[mnu[menu_pt].hotkey])) && (mnu[menu_pt].com != M_SEPARATOR))
                            {
                                Write_KB(KEY_ENTER);
                                old_menu_pt = menu_pt;
                                old_i = i;
                                break;
                            }
                            go_next_menu(mnu);
                            i++;
                        }
                    }
                    menu_pt = old_menu_pt;
                    i = old_i;
                }
        }
    }
    while((ch != KEY_ENTER) && (ch != KEY_ESC));

    Set_TColor(old_tcolor);
    Set_EngOnlyKey(old_eng_key);
/*    free(xx); */
    if(ch == KEY_ESC)
        return 0;
    if(mnu[menu_pt].com == M_POPUP)
        return ret;
    return(mnu[menu_pt].com);
}

/* ======================================= */

int t1(font *fn, font *ifn)
{

    int i, j, hi;
    char st[] = "the quick brown fox jumps over the lazy dog";

    Rectangle(0, 0, 639, 479, WHITE);
    for(j = 0; j < 16; j++)
    {
        hi = Thai_Hight();
        Solid_Box(0, 0, 639, 479, 0);
        for(i = 0; i < 16; i++)
            Solid_Box(0, i * hi, Thai_Width(st), i * hi + hi, i);
        Set_TColor(j);

        Set_TFont(fn);
        for(i = 0; i < 8; i++)
        {
            Out_ThaiV(i, i * 20, st);
        }

        Set_TFont(ifn);
        for(i = 8; i < 16; i++)
        {
            Out_ThaiV(0, i * 20, st);
        }

        getch();
    }
    return 0;
}

int t2(font *fn)
{


    int i, j, hi;
    char st1[] = "���������������������������������������������������������";
    char st2[] = "�     ���������ش������԰���Ȥس���  ���Һ�ôҽ٧�ѵ����Ѩ�ҹ     �";
    char st3[] = "�����ҿѹ�Ѳ���Ԫҡ��              ������ҧ��ҭ���蹦�Һձ���  �";
    char st4[] = "���������ø�觫Ѵ�ִ�Ѵ���        �Ѵ��������͹�����Ѫ�����      �";
    char st5[] = "���ԺѵԻ�оĵԡ���˹��           �ٴ����� ��� � ��� ��ҿѧ����  �";
    char st6[] = "���������������������������������������������������������";
    char st7[] = "�ӹǹ�ҵðҹ";

    Rectangle(0, 0, 639, 479, WHITE);

    Set_TFont(fn);
    Set_TColor(2);

    Out_ThaiV(90, 15, st1);
    Out_ThaiV(90, 35, st2);
    Out_ThaiV(90, 55, st3);
    Out_ThaiV(90, 75, st4);
    Out_ThaiV(90, 95, st5);
    Out_ThaiV(90, 115, st6);
    Out_ThaiV(440, 135, st7);

    getch();
    return 0;
}

int t3(font *fn)
{

    static char title[80] = "", filename[80] = "";

    Set_TFont(fn);

    Rectangle(0, 0, 639, 479, WHITE);

    Solid_Box(150, 170, 490, 270, LIGHTGRAY);
    Rectangle(150, 170, 490, 270, LIGHTBLUE);
    Set_EditBKColor(15);
    Set_TColor(0);
    Out_ThaiV(160, 180, "Title");
    Out_ThaiV(160, 220, "Filename");
    Add_Get(160, 200, G_THAI, 40, 80, title);
    Add_Get(160, 240, G_ENGLISH, 40, 80, filename);
    Read_Get();
    return 0;
}

#define COMMAND1 1
#define COMMAND2 2
#define COMMAND3 3
#define COMMAND4 4
#define COMMAND5 5
#define COMMAND6 6
#define COMMAND7 7
#define EXIT 100

MenuItem main_menu[] = {
    {"Menu 1", 5, M_POPUP},
    {"Menu 2", 5, COMMAND2},
    {"Menu 3", 5, COMMAND3},
    {"Menu 4", 5, COMMAND4},
    {"Menu 5", 5, COMMAND5},
    {"", 0, M_SEPARATOR},
    {"Menu 6", 5, COMMAND6},
    {"", 0, M_END},
    {"Menu 7", 5, COMMAND7},
    {"Exit", 0, EXIT},
    {"", 0, M_END}
};

int t4(font *fn)
{

    int mnu;

    Set_TColor(15);
    Set_TFont(fn);
    Disable_Menu(COMMAND4);
    Check_Menu(COMMAND5);
    do
    {
        mnu = Menu(0, 0, main_menu);
        switch(mnu)
        {
            case COMMAND5:
                if(Is_Check_Menu(COMMAND5))
                    UnCheck_Menu(COMMAND5);
                else
                    Check_Menu(COMMAND5);
            case COMMAND1:
            case COMMAND2:
            case COMMAND3:
            case COMMAND4:
            case COMMAND6:
            case COMMAND7:
            {
                char st[80];
                sprintf(st, "You select command %d", mnu);
                Out_ThaiV(0, 200, st);
                Get_KB();
                Clear_Screen();
            }
       }
    }
    while(mnu != EXIT);
    return mnu;
}

void Show_KMITT_logo(int x, int y, char *path)
{
    FILE *lgo;
    int plan,i;
    unsigned char *ll;
    unsigned char far *scr;

    if((ll = malloc(32)) == NULL)
        return;
    x = x / 8;
    lgo = fopen(path, "rb");
    if(lgo != NULL)
    {
        for(plan = 0 ; plan < 2; plan++)
        {
            switch(plan)
            {
                case 0 : set_writecolor(7);
                    break;
                case 1 : set_writecolor(8);
                    break;
            }

            for(i = 0; i < 256; i++)
            {
                scr = MK_FP(0xA000, (i + y) * 80 + x);
                fread(ll, 1, 32, lgo);
                _fmemcpy(scr, ll, 32);
            }

        }

        fclose(lgo);
    }

    free(ll);
}

int main()
{

    static font fn[256], ifn[256];

    Set_Mode(VM_GRAPHIC);

    if(Load_TFont(fn, "NORMAL.FON"))
        exit(1);
    if(Load_TFont(ifn, "ITALIC.FON"))
        exit(1);

    t1(fn, ifn);
    Clear_Screen();

    t2(fn);
    Clear_Screen();

    t3(fn);
    Clear_Screen();
	
	Show_KMITT_logo(100, 100, "KMITT.LGO");
	getch();
	Clear_Screen();
	
    t4(fn);

    Set_Mode(VM_TEXT);
    return 0;
}
